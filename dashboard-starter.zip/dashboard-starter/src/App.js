import React, { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [balance, setBalance] = useState(null);
  const [quota, setQuota] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        // Example API call placeholder (replace with Lighter endpoint)
        const response = await axios.get('/api/balance', {
          headers: {
            'x-api-key-index': process.env.REACT_APP_API_KEY_INDEX,
            'x-public-key': process.env.REACT_APP_PUBLIC_KEY,
            'x-private-key': process.env.REACT_APP_PRIVATE_KEY,
          },
        });
        setBalance(response.data.balance || 1000); // placeholder value
        setQuota(response.data.quota || 500);     // placeholder value
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  if (loading) return <div className="p-6 text-xl">Loading Dashboard...</div>;

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <h1 className="text-3xl font-bold mb-6">Trading Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gray-800 p-6 rounded-xl shadow-md">
          <h2 className="text-lg font-semibold mb-2">Available Balance</h2>
          <p className="text-2xl">${balance}</p>
        </div>
        <div className="bg-gray-800 p-6 rounded-xl shadow-md">
          <h2 className="text-lg font-semibold mb-2">Quota Remaining</h2>
          <p className="text-2xl">{quota}</p>
        </div>
      </div>
    </div>
  );
}

export default App;